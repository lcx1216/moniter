package com.gis.monitor.service;

import com.gis.monitor.mapper.basicinfo.BI_MONTHLY_REPORT_MAPPER;
import com.gis.monitor.pojo.basicinfo.BI_MONTHLY_REPORT;
import com.gis.monitor.mapper.basicinfo.BI_SUB_EARTHRESISTIVITY_MAPPER;
import com.gis.monitor.pojo.basicinfo.BI_SUB_EARTHRESISTIVITY;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;


public class BasicInfoService {


    @Resource
    BI_MONTHLY_REPORT_MAPPER bi_monthly_report_mapper;
    public List<BI_MONTHLY_REPORT> selectList(){
        List<BI_MONTHLY_REPORT> list3 = new ArrayList<BI_MONTHLY_REPORT>();
        list3 = bi_monthly_report_mapper.getRatingTimeList();
        return list3;
    }
    @Resource
    BI_SUB_EARTHRESISTIVITY_MAPPER bi_sub_earthresistivity_mapper;
    public List<BI_SUB_EARTHRESISTIVITY> getStationId() {
        List<BI_SUB_EARTHRESISTIVITY> list4 = new ArrayList<BI_SUB_EARTHRESISTIVITY>();
        list4 = bi_sub_earthresistivity_mapper.getStationIdList();
        return list4;

    }
}
