package com.gis.monitor.controller;

/*
地电阻率观测系统评估(改)
 */


public class OS_EarthResistivity {
//    String  station;
//    String  item;
//    public Point point;
//
//    public OS_EarthResistivity(Station station, Item item, Point point) {
//        station_id = station;
//        point_id = point;
//        item_id = substr(item, 0, 3);
//        mode = M('bi_sub_earthresistivity', '', 'CONFIG_JC_BASICINFO');
//        mode1 = M('mg_scoremanager_ddz', '', 'CONFIG_JC_MANAGEGRADE');
//        results = mode->where("ITEMID='%s' and STATIONID='%s' and POINTID='%s' AND STATE='1'", $item_id, $station_id, $point_id)->select();
//        results1 = mode1->field("EVALUATIONPRO3,EVALUATIONPRO4,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='观测系统评估'")->order('ID desc')->select();
//        unset(mode);
//        unset(mode1);
//        // var_dump($results);
//        // // echo "</br>---------------------</br>";
//        //  var_dump($results1);
//        // exit;
//        //地质地貌条件
//        count_grade1 = 0;
//        //1.1观测场地宜选在地震活动带内或在活动断裂带附近     EN_D_FAULT2STA
//        count_grade1s = 0;
//        if ((double)results[0]['EN_D_FAULT2STA'] > 0 && (double)results[0]['EN_D_FAULT2STA'] < (double)results1[37]['MAX'] && !is_null(results[0]['EN_D_FAULT2STA'])) {
//            count_grade1s = (double)results1[37]['SCORE'];
//        } else if ((double)results[0]['EN_D_FAULT2STA'] >= (double)results1[38]['MIN'] && (double)results[0]['EN_D_FAULT2STA'] < (double)results1[38]['MAX']) {
//            count_grade1s = (double)results1[38]['SCORE'];
//        } else if ((double)results[0]['EN_D_FAULT2STA'] >= (double)results1[39]['MIN'] && (double)results[0]['EN_D_FAULT2STA'] < (double)results1[39]['MAX']) {
//            count_grade1s = (double)results1[39]['SCORE'];
//        } else if ((double)results[0]['EN_D_FAULT2STA'] >= (double)results1[40]['MIN'] && (double)results[0]['EN_D_FAULT2STA'] < 999999) {
//            count_grade1s = (double)results1[40]['SCORE'];
//        } else {
//            (double)results[0]['EN_D_FAULT2STA'] = 999999;
//            count_grade1s = (double)results1[40]['SCORE'];
//        }
//        //1.2布极区应地形开阔、地势平坦，地形高差不宜大于电极间距的5％    SEPSED
//        count_grade12 = 0;
//        if (results[0]['SEPSED'] <= 1) {
//            if ((double)results[0]['SEPSED'] * 100 >= 0 && (double)results[0]['SEPSED'] * 100 <= (double)results1[41]['MAX'] && !is_null($results[0]['SEPSED'])) {
//                $count_grade12 = (double)$results1[41]['SCORE'];
//            } else if ((double)$results[0]['SEPSED'] * 100 >= (double)$results1[43]['MIN'] && (double)$results[0]['SEPSED'] * 100 <= (double)$results1[43]['MAX']) {
//                $count_grade12 = (double)$results1[43]['SCORE'];
//            } else if ((double)$results[0]['SEPSED'] * 100 >= (double)$results1[42]['MIN'] && (double)$results[0]['SEPSED'] * 100 < 999999) {
//                $count_grade12 = (double)$results1[42]['SCORE'];
//            } else {
//                (double)$results[0]['SEPSED'] = 999999;
//                $count_grade12 = (double)$results1[42]['SCORE'];
//            }
//        } else {
//            if ((double)$results[0]['SEPSED'] >= 0 && (double)results[0]['SEPSED'] <= (double)results1[41]['MAX'] && !is_null(results[0]['SEPSED'])) {
//                count_grade12 = (double)results1[41]['SCORE'];
//            } else if ((double)results[0]['SEPSED'] >= (double)results1[43]['MIN'] && (double)results[0]['SEPSED'] <= (double)results1[43]['MAX']) {
//                count_grade12 = (double)results1[43]['SCORE'];
//            } else if ((double)results[0]['SEPSED'] >= (double)results1[42]['MIN'] && (double)results[0]['SEPSED'] < 999999) {
//                count_grade12 = (double)results1[42]['SCORE'];
//            } else {
//                (double)results[0]['SEPSED'] = 999999;
//                count_grade12 = (double)results1[42]['SCORE'];
//            }
//        }
//        //1.3布极区内不应有沟壑、崖坎、河流等   GCRNUM
//        count_grade13 = 0;
//        //var_dump($results1);
//        //var_dump((double)$results1[45]['MIN']);
//        //var_dump((double)$results[0]['GCRNUM']);
//        //var_dump((double)$results1[44]['MIN']);
//        if ((double)results[0]['GCRNUM'] >= (double)results1[44]['MIN'] && results[0]['GCRNUM'] != null && (double)results[0]['GCRNUM'] != 999999) {
//            echo "string";
//            count_grade13 = (double)results1[44]['SCORE']; //>3 0.1
//
//        } else if ((double)results[0]['GCRNUM'] >= (double)results1[45]['MIN'] && (double)results[0]['GCRNUM'] <= (double)results1[45]['MAX']) {
//            count_grade13 = (double)results1[45]['SCORE'];
//        } else if ((double)results[0]['GCRNUM'] == 0 && results[0]['GCRNUM'] != null) {
//            count_grade13 = (double)results1[46]['SCORE'];
//        } else {
//            (double)results[0]['GCRNUM'] = 999999;
//            count_grade13 = (double)results1[46]['SCORE']; //0.3
//
//        }
//        count_grade1 = count_grade1s + count_grade12 + count_grade13;
//        //水文地质条件
//        count_grade2 = 0;
//        //2.1布极区不宜选在抽水漏斗区内（0.5分）； IS_PFIPC
//        count_grade21 = 0;
//        if (results[0]['IS_PFIPC'] === results1[23]['TYPE']) {
//            count_grade21 = (double)results1[23]['SCORE'];
//        } else if (results[0]['IS_PFIPC'] === results1[22]['TYPE']) {
//            count_grade21 = (double)results1[22]['SCORE'];
//        } else {
//            (double)results[0]['IS_PFIPC'] = 999999;
//            count_grade21 = (double)results1[22]['SCORE'];
//        }
//        //2.2布极区边缘避开大型水库、湖泊的距离不宜小于3km（0.5分）；D_LRLD
//        count_grade22 = 0;
//        if ((double)results[0]['D_LRLD'] <= (double)results1[24]['MAX'] && !is_null(results[0]['D_LRLD'])) {
//            count_grade22 = (double)results1[24]['SCORE']; //<0.2
//
//        } else if ((double)results[0]['D_LRLD'] > (double)results1[27]['MIN'] && (double)results[0]['D_LRLD'] <= (double)results1[27]['MAX']) {
//           $count_grade22 = (double)results1[27]['SCORE']; //0.2~1
//
//        } else if ((double)results[0]['D_LRLD'] > (double)results1[26]['MIN'] && (double)results[0]['D_LRLD'] <= (double)results1[26]['MAX']) {
//            count_grade22 = (double)results1[26]['SCORE']; //1~3
//
//        } else if ((double)results[0]['D_LRLD'] > 0 && (double)results[0]['D_LRLD'] <= (double)results1[25]['MAX']) {
//            count_grade22 = (double)results1[25]['SCORE']; //1~3
//
//        } else if (results[0]['D_LRLD'] === 0) {
//            count_grade22 = (double)results1[25]['SCORE']; //1~3
//
//        } else {
//            (double)results[0]['D_LRLD'] = 999999;
//            count_grade22 = (double)results1[25]['SCORE'];
//        }
//        //var_dump($results[0]['D_LRLD']);
//        //var_dump($count_grade22);
//        count_grade2 = count_grade21 + count_grade22;
//        //岩性条件
//        count_grade3 = 0;
//        //3.1布极区表层不应为卵石层、砾石层（1.0分）；IS_PSGL
//        count_grade31 = 0;
//        if (results[0]['IS_PSGL'] === results1[21]['TYPE']) {
//            count_grade31 = (double)results1[21]['SCORE'];
//        } else if (results[0]['IS_PSGL'] === results1[20]['TYPE']) {
//            count_grade31 = (double)results1[20]['SCORE'];
//        } else {
//            (double)results[0]['IS_PSGL'] = 999999;
//            count_grade31 = (double)results1[20]['SCORE'];
//        }
//        //3.2土层、砂土层及卵石、砾石组成的第四系覆盖层的厚度不宜超过200m（1.0分）；CT
//        count_grade32 = 0;
//        if ((double)results[0]['CT'] < (double)results1[16]['MAX'] && (double)results[0]['CT'] > 0) {
//            count_grade32 = (double)results1[16]['SCORE']; //① 小于200 m（1.0分）
//
//        } else if (results[0]['CT'] === 0) {
//            count_grade32 = (double)results1[16]['SCORE']; //① 小于200 m（1.0分）
//
//        } else if ((double)results[0]['CT'] >= (double)results1[19]['MIN'] && (double)results[0]['CT'] < (double)results1[19]['MAX']) {
//            count_grade32 = (double)results1[19]['SCORE']; //② 200-300 m（0.8分）
//
//        } else if ((double)results[0]['CT'] >= (double)results1[18]['MIN'] && (double)results[0]['CT'] <= (double)results1[18]['MAX']) {
//            count_grade32 = (double)results1[18]['SCORE']; //③ 300-500 m（0.6分）
//
//        } else if ((double)results[0]['CT'] >= (double)results1[17]['MIN'] && (double)results[0]['CT'] <= 999999) {
//            count_grade32 = (double)results1[17]['SCORE']; //④ 大于500 m（0.5分）
//
//        } else {
//            (double)results[0]['CT'] = 999999;
//            count_grade32 = (double)results1[17]['SCORE'];
//        }
//        count_grade3 = count_grade31 + count_grade32;
//        //电性结构
//        count_grade4 = 0;
//        //4.1供电电极距100m时测得的视电阻率宜在10 Ωm-50 Ωm（1.0分）；PDHRV
//        count_grade41 = 0;
//        if ((double)results[0]['PDHRV'] < (double)results1[28]['MAX'] && !is_null(results[0]['PDHRV'])) {
//            count_grade41 = (double)results1[28]['SCORE'];
//        } else if ((double)results[0]['PDHRV'] >= (double)results1[32]['MIN'] && (double)results[0]['PDHRV'] < (double)results1[32]['MAX']) {
//            count_grade41 = (double)results1[32]['SCORE'];
//        } else if ((double)results[0]['PDHRV'] >= (double)results1[29]['MIN'] && (double)results[0]['PDHRV'] < (double)results1[29]['MAX']) {
//            count_grade41 = (double)results1[29]['SCORE'];
//        } else if ((double)results[0]['PDHRV'] >= (double)results1[31]['MIN'] && (double)results[0]['PDHRV'] <= (double)results1[31]['MAX']) {
//            count_grade41 = (double)results1[31]['SCORE'];
//        } else if ((double)results[0]['PDHRV'] >= (double)results1[30]['MIN'] && (double)results[0]['PDHRV'] <= 999999) {
//            count_grade41 = (double)results1[30]['SCORE'];
//        } else {
//            (double)results[0]['PDHRV'] = 999999;
//            count_grade41 = (double)results1[30]['SCORE'];
//        }
//        //4.2表层影响系数S的绝对值宜小于0.2（1.0分）；ASIC
//        count_grade42 = 0;
//        if ((double)results[0]['ASIC'] < (double)results1[33]['MAX'] && !is_null(results[0]['ASIC'])) {
//            count_grade42 = (double)results1[33]['SCORE'];
//        } else if ((double)results[0]['ASIC'] >= (double)results1[36]['MIN'] && (double)results[0]['ASIC'] < (double)results1[28]['MAX']) {
//            count_grade42 = (double)results1[36]['SCORE'];
//        } else if ((double)results[0]['ASIC'] >= (double)results1[35]['MIN'] && (double)results[0]['ASIC'] < (double)results1[35]['MAX']) {
//            count_grade42 = (double)results1[35]['SCORE'];
//        } else if ((double)results[0]['ASIC'] >= (double)results1[34]['MIN'] && (double)results[0]['ASIC'] < 999999) {
//            count_grade42 = (double)results1[34]['SCORE'];
//        } else {
//            (double)results[0]['ASIC'] = 999999;
//            count_grade42 = (double)results1[34]['SCORE'];
//        }
//        count_grade4 = $count_grade41 + $count_grade42;
//        //场地电磁环境
//        count_grade5 = 0;
//        //5.1非工频人工电磁源在测量极间产生的干扰电压不大于45 μV（1.0分）；NPFEV
//        count_grade51 = 0;
//        if ((double)results[0]['NPFEV'] <= (double)results1[50]['MAX'] && !is_null(results[0]['NPFEV'])) {
//            count_grade51 = (double)results1[50]['SCORE'];
//        } else if ((double)results[0]['NPFEV'] > (double)results1[51]['MIN'] && (double)results[0]['NPFEV'] <= (double)results1[51]['MAX']) {
//            count_grade51 = (double)results1[51]['SCORE'];
//        } else if ((double)results[0]['NPFEV'] > (double)results1[52]['MIN'] && (double)results[0]['NPFEV'] <= 999999) {
//            count_grade51 = (double)results1[52]['SCORE'];
//        } else {
//            (double)results[0]['NPFEV'] = 999999;
//            count_grade51 = (double)results1[52]['SCORE'];
//        }
//        //     var_dump( $count_grade51);
//        // var_dump($results[0]['NPFEV'] );
//        //5.2工频人工电磁源在测量极间产生的干扰峰值电压 不大于500 mV（1.0分）；IPPFE
//        count_grade52 = 0;
//        if ((double)results[0]['IPPFE'] <= (double)results1[47]['MAX'] && !is_null(results[0]['IPPFE'])) {
//            count_grade52 = (double)results1[47]['SCORE'];
//        } else if ((double)results[0]['IPPFE'] > (double)results1[48]['MIN'] && (double)results[0]['IPPFE'] <= (double)results1[48]['MAX']) {
//            count_grade52 = (double)results1[48]['SCORE'];
//        } else if ((double)results[0]['IPPFE'] > (double)results1[49]['MIN'] && (double)results[0]['IPPFE'] <= 999999) {
//            count_grade52 = (double)results1[49]['SCORE'];
//        } else {
//            (double)results[0]['IPPFE'] = 999999;
//            count_grade52 = (double)results1[49]['SCORE'];
//        }
//        count_grade5 = count_grade51 + count_grade52;
//        //测区观测环境
//        count_grade6 = 0;
//        //6.1城市电气化地（城）铁轨道与观测场地中心的距离不小于30 km（1分）；D_CERCF
//        count_grade61 = 0;
//        if ((double)results[0]['D_CERCF'] < (double)results1[61]['MAX'] && !is_null(results[0]['D_CERCF'])) {
//            count_grade61 = (double)$results1[61]['SCORE']; //<5 0.3
//
//        } else if ((double)$results[0]['D_CERCF'] > (double)$results1[64]['MIN'] && (double)$results[0]['D_CERCF'] <= (double)$results1[64]['MAX']) {
//            $count_grade61 = (double)$results1[64]['SCORE']; //15~30
//
//        } else if ((double)$results[0]['D_CERCF'] >= (double)$results1[62]['MIN'] && (double)$results[0]['D_CERCF'] <= (double)$results1[62]['MAX']) {
//            $count_grade61 = (double)$results1[62]['SCORE']; //5~15
//
//        } else if ((double)$results[0]['D_CERCF'] > (double)$results1[63]['MIN']) {
//            $count_grade61 = (double)$results1[63]['SCORE']; //>30
//
//        } else {
//            (double)$results[0]['D_CERCF'] = 999999;
//            $count_grade61 = (double)$results1[63]['SCORE'];
//        }
//        //6.2电气化铁路运输系统在牵引功率不超过6000kW的条件下，轨道与任意一个测向中心点的距离不小于5 km（1分）；MD_CETRC_BSIX
//        $count_grade62 = 0;
//        if ((double)$results[0]['MD_CETRC_BSIX'] < (double)$results1[57]['MAX'] && !is_null($results[0]['MD_CETRC_BSIX'])) {
//            $count_grade62 = (double)$results1[57]['SCORE']; //<0.2
//
//        } else if ((double)$results[0]['MD_CETRC_BSIX'] >= (double)$results1[59]['MIN'] && (double)$results[0]['MD_CETRC_BSIX'] <= (double)$results1[59]['MAX']) {
//            $count_grade62 = (double)$results1[59]['SCORE']; //1~5
//
//        } else if ((double)$results[0]['MD_CETRC_BSIX'] >= (double)$results1[60]['MIN'] && (double)$results[0]['MD_CETRC_BSIX'] < (double)$results1[60]['MAX']) {
//            $count_grade62 = (double)$results1[60]['SCORE']; //0.2~1
//
//        } else if ((double)$results[0]['MD_CETRC_BSIX'] > (double)$results1[58]['MIN'] && (double)$results[0]['MD_CETRC_BSIX'] < 999999) {
//            $count_grade62 = (double)$results1[58]['SCORE']; //>5
//
//        } else {
//            (double)$results[0]['MD_CETRC_BSIX'] = 999999;
//            $count_grade62 = (double)$results1[58]['SCORE'];
//        }
//        //6.3普通铁路运输系统轨道与任意一个测向的中心点的距离不小于1 km（1.0分）；MD_CR
//        $count_grade63 = 0;
//        if ((double)$results[0]['MD_CR'] < (double)$results1[53]['MAX'] && !is_null($results[0]['MD_CR'])) {
//            $count_grade63 = (double)$results1[53]['SCORE']; //<0.05
//
//        } else if ((double)$results[0]['MD_CR'] >= (double)$results1[55]['MIN'] && (double)$results[0]['MD_CR'] < (double)$results1[55]['MAX']) {
//            $count_grade63 = (double)$results1[55]['SCORE']; //0.5~1
//
//        } else if ((double)$results[0]['MD_CR'] >= (double)$results1[56]['MIN'] && (double)$results[0]['MD_CR'] <= (double)$results1[56]['MAX']) {
//            $count_grade63 = (double)$results1[56]['SCORE']; //0.05~0.5
//
//        } else if ((double)$results[0]['MD_CR'] >= (double)$results1[54]['MIN']) {
//            $count_grade63 = (double)$results1[54]['SCORE']; //>1
//
//        } else {
//            (double)$results[0]['MD_CR'] = 999999;
//            $count_grade63 = (double)$results1[54]['SCORE'];
//        }
//        //6.4 35kV以上、500kV以下高压交流输电线路与任一测量极的距离应不小于300m（1.0分）； MD_HVT_THRKTFK
//        $count_grade64 = 0;
//        if ((double)$results[0]['MD_HVT_THRKTFK'] < (double)$results1[69]['MAX'] && !is_null($results[0]['MD_HVT_THRKTFK'])) {
//            $count_grade64 = (double)$results1[69]['SCORE']; //<20
//
//        } else if ((double)$results[0]['MD_HVT_THRKTFK'] >= (double)$results1[70]['MIN'] && (double)$results[0]['MD_HVT_THRKTFK'] <= (double)$results1[70]['MAX']) {
//            $count_grade64 = (double)$results1[70]['SCORE']; //50~300
//
//        } else if ((double)$results[0]['MD_HVT_THRKTFK'] >= (double)$results1[72]['MIN'] && (double)$results[0]['MD_HVT_THRKTFK'] < (double)$results1[72]['MAX']) {
//            $count_grade64 = (double)$results1[72]['SCORE']; //20~50
//
//        } else if ((double)$results[0]['MD_HVT_THRKTFK'] >= (double)$results1[71]['MIN']) {
//            $count_grade64 = (double)$results1[71]['SCORE']; //>300
//
//        } else {
//            (double)$results[0]['MD_HVT_THRKTFK'] = 999999;
//            $count_grade64 = (double)$results1[71]['SCORE'];
//        }
//        //6.5 500kV以上高压交流输电线路与任一测量极的距离应不小于1.5 km（1.0分）；MD_HVT_F
//        $count_grade65 = 0;
//        if ((double)$results[0]['MD_HVT_F'] < (double)$results1[65]['MAX'] && !is_null($results[0]['MD_HVT_F'])) {
//            $count_grade65 = (double)$results1[65]['SCORE']; //④ 小于0.05 km      （0.3分）0
//
//        } else if ((double)$results[0]['MD_HVT_F'] >= (double)$results1[67]['MIN'] && (double)$results[0]['MD_HVT_F'] < (double)$results1[67]['MAX']) {
//            $count_grade65 = (double)$results1[67]['SCORE']; //② 0.15-1.5 km       （0.8分）
//
//        } else if ((double)$results[0]['MD_HVT_F'] >= (double)$results1[68]['MIN'] && (double)$results[0]['MD_HVT_F'] <= (double)$results1[68]['MAX']) {
//            $count_grade65 = (double)$results1[68]['SCORE']; //③ 0.05-0.15 km      （0.5分）
//
//        } else if ((double)$results[0]['MD_HVT_F'] > (double)$results1[66]['MIN']) {
//            $count_grade65 = (double)$results1[66]['SCORE']; // ① 无或大于1.5 km   （1.0分）999999
//
//        } else {
//            (double)$results[0]['MD_HVT_F'] = 999999;
//            $count_grade65 = (double)$results1[66]['SCORE'];
//        }
//        //6.6 30kW以下变压器或相当功率的用电器，接地线与任一测量极的距离应不小于50 m（1.0分）；  MD_GWM
//        $count_grade66 = 0;
//        if ((double)$results[0]['MD_GWM'] < (double)$results1[78]['MAX'] && !is_null($results[0]['MD_GWM'])) {
//            $count_grade66 = (double)$results1[78]['SCORE']; //④ 小于10 m        （0.3分）0
//
//        } else if ((double)$results[0]['MD_GWM'] >= (double)$results1[75]['MIN'] && (double)$results[0]['MD_GWM'] <= (double)$results1[75]['MAX']) {
//            $count_grade66 = (double)$results1[75]['SCORE']; //② 30-50 m         （0.8分）
//
//        } else if ((double)$results[0]['MD_GWM'] >= (double)$results1[76]['MIN'] && (double)$results[0]['MD_GWM'] < (double)$results1[76]['MAX']) {
//            $count_grade66 = (double)$results1[76]['SCORE']; //③ 10-30 m         （0.5分）
//
//        } else if ((double)$results[0]['MD_GWM'] > (double)$results1[74]['MIN']) {
//            $count_grade66 = (double)$results1[74]['SCORE']; //① 无或大于50 m    （1.0分）999999
//
//        } else {
//            (double)$results[0]['MD_GWM'] = 999999;
//            $count_grade66 = (double)$results1[74]['SCORE'];
//        }
//        //6.7  30kW以上变压器或相当功率的用电器，接地线与任一测量极的距离应不小于100 m（1.0分）；  MD_TGW_THRTK
//        $count_grade67 = 0;
//        //var_dump($results1);
//        if ((double)$results[0]['MD_TGW_THRTK'] < (double)$results1[73]['MAX'] && !is_null($results[0]['MD_TGW_THRTK'])) {
//            $count_grade67 = (double)$results1[73]['SCORE']; //④ 小于10 m         （0.3分）0
//
//        } else if ((double)$results[0]['MD_TGW_THRTK'] >= (double)$results1[79]['MIN'] && (double)$results[0]['MD_TGW_THRTK'] <= (double)$results1[79]['MAX']) {
//            $count_grade67 = (double)$results1[79]['SCORE']; //② 30-100 m         （0.8分）
//
//        } else if ((double)$results[0]['MD_TGW_THRTK'] >= (double)$results1[80]['MIN'] && (double)$results[0]['MD_TGW_THRTK'] < (double)$results1[80]['MAX']) {
//            $count_grade67 = (double)$results1[80]['SCORE']; //③ 10-30 m          （0.5分）
//
//        } else if ((double)$results[0]['MD_TGW_THRTK'] > (double)$results1[77]['MIN']) {
//            $count_grade67 = (double)$results1[77]['SCORE']; //① 无或大于100 m    （1.0分）999999
//
//        } else {
//            (double)$results[0]['MD_TGW_THRTK'] = 999999;
//            $count_grade67 = (double)$results1[77]['SCORE']; //1
//
//        }
//        $count_grade6 = $count_grade61 + $count_grade62 + $count_grade63 + $count_grade64 + $count_grade65 + $count_grade66 + $count_grade67;
//        //7.1电极应采用铅板电极（0.3分）；IS_ELF
//        $count_grade7 = 0;
//        if ($results[0]['IS_ELF'] === $results1[12]['TYPE']) {
//            $count_grade7 = (double)$results1[12]['SCORE'];
//        } else if ($results[0]['IS_ELF'] === $results1[13]['TYPE']) {
//            $count_grade7 = (double)$results1[13]['SCORE'];
//        } else {
//            (double)$results[0]['IS_ELF'] = 999999;
//            $count_grade7 = (double)$results1[13]['SCORE'];
//        }
//        //8.1线电阻不应大于20Ω/km，拉断力不宜小于2000Ｎ（0.2分）；ECR
//        $count_grade8 = 0;
//        if ($results[0]['ECR'] === $results1[0]['TYPE']) {
//            $count_grade8 = (double)$results1[0]['SCORE'];
//        } else if ($results[0]['ECR'] === $results1[1]['TYPE']) {
//            $count_grade8 = (double)$results1[1]['SCORE'];
//        } else {
//            (double)$results[0]['ECR'] = 999999;
//            $count_grade8 = (double)$results1[1]['SCORE'];
//        }
//        //9.1宜有无间隙封闭式避雷器或有间隙放电式避雷器（0.5分）；IS_LPD
//        $count_grade9 = 0;
//        if ($results[0]['IS_LPD'] === $results1[14]['TYPE']) {
//            $count_grade9 = (double)$results1[14]['SCORE'];
//        } else if ($results[0]['IS_LPD'] === $results1[15]['TYPE']) {
//            $count_grade9 = (double)$results1[15]['SCORE'];
//        } else {
//            (double)$results[0]['IS_LPD'] = 999999;
//            $count_grade9 = (double)$results1[15]['SCORE'];
//        }
//        $count_grade10 = 0;
//        //10.1 应有潜水位观测（0.8分）；IS_WLOB
//        $count_grade101 = 0;
//        if ($results[0]['IS_WLOB'] === $results1[8]['TYPE']) {
//            $count_grade101 = (double)$results1[8]['SCORE'];
//        } else if ($results[0]['IS_WLOB'] === $results1[9]['TYPE']) {
//            $count_grade101 = (double)$results1[9]['SCORE'];
//        } else {
//            (double)$results[0]['IS_WLOB'] = 999999;
//            $count_grade101 = (double)$results1[9]['SCORE'];
//        }
//        //10.2 应有降雨量观测（0.8分）；IS_PREOB
//        $count_grade102 = 0;
//        if ($results[0]['IS_PREOB'] === $results1[10]['TYPE']) {
//            $count_grade102 = (double)$results1[10]['SCORE'];
//        } else if ($results[0]['IS_PREOB'] === $results1[11]['TYPE']) {
//            $count_grade102 = (double)$results1[11]['SCORE'];
//        } else {
//            (double)$results[0]['IS_PREOB'] = 999999;
//            $count_grade102 = (double)$results1[11]['SCORE'];
//        }
//        //10.3 应有温度观测（0.4分）；IS_TEMOB
//        $count_grade103 = 0;
//        if ($results[0]['IS_TEMOB'] === $results1[6]['TYPE']) {
//            $count_grade103 = (double)$results1[6]['SCORE'];
//        } else if ($results[0]['IS_TEMOB'] === $results1[7]['TYPE']) {
//            $count_grade103 = (double)$results1[7]['SCORE'];
//        } else {
//            (double)$results[0]['IS_TEMOB'] = 999999;
//            $count_grade103 = (double)$results1[7]['SCORE'];
//        }
//        $count_grade10 = $count_grade101 + $count_grade102 + $count_grade103;
//        $count_grade11 = 0;
//        //11.1 应有电测深曲线或高密度剖面资料（1.0分）；IS_ESC_HDPD
//        $count_grade111 = 0;
//        if ($results[0]['IS_ESC_HDPD'] === $results1[2]['TYPE']) {
//            $count_grade111 = (double)$results1[2]['SCORE'];
//        } else if ($results[0]['IS_ESC_HDPD'] === $results1[3]['TYPE']) {
//            $count_grade111 = (double)$results1[3]['SCORE'];
//        } else {
//            (double)$results[0]['IS_ESC_HDPD'] = 999999;
//            $count_grade111 = (double)$results1[3]['SCORE'];
//        }
//        //11.2 应有测区地层剖面或柱状资料（1.0分）；IS_FP_CD
//        $count_grade112 = 0;
//        if ($results[0]['IS_FP_CD'] === $results1[4]['TYPE']) {
//            $count_grade112 = (double)$results1[4]['SCORE'];
//        } else if ($results[0]['IS_FP_CD'] === $results1[5]['TYPE']) {
//            $count_grade112 = (double)$results1[5]['SCORE'];
//        } else {
//            (double)$results[0]['IS_FP_CD'] = 999999;
//            $count_grade112 = (double)$results1[5]['SCORE'];
//        }
//        $count_grade11 = $count_grade111 + $count_grade112;
//        $count_grade1_1 = $count_grade1 + $count_grade2 + $count_grade3 + $count_grade4 + $count_grade5 + $count_grade6;
//        $count_grade2_1 = $count_grade7 + $count_grade8 + $count_grade9 + $count_grade10 + $count_grade11;
//        $ss = array();
//        // if ($results==null) {
//        // $count_grade11=$count_grade12=$count_grade13=$count_grade21=$count_grade22=$count_grade31=$count_grade32=$count_grade41=$count_grade42=$count_grade51=$count_grade52=$count_grade61=$count_grade62=$count_grade63=$count_grade64=$count_grade65=$count_grade66=$count_grade67=$count_grade7=$count_grade8=$count_grade9=$count_grade101=$count_grade102=$count_grade103=$count_grade111=$count_grade112=$count_grade1_1=$count_grade2_1=0;
//        // $results[0]['EN_D_FAULT2STA']='999999';
//        // $results[0]['SEPSED']='999999';
//        // $results[0]['GCRNUM']='999999';
//        // $results[0]['IS_PFIPC']='999999';
//        // $results[0]['D_LRLD']='999999';
//        // $results[0]['IS_PSGL']='999999';
//        // $results[0]['CT']='999999';
//        // $results[0]['PDHRV']='999999';
//        // $results[0]['ASIC']='999999';
//        // $results[0]['NPFEV']='999999';
//        // $results[0]['IPPFE']='999999';
//        // $results[0]['D_CERCF']='999999';
//        // $results[0]['MD_CETRC_BSIX']='999999';
//        // $results[0]['MD_CR']='999999';
//        // $results[0]['MD_HVT_THRKTFK']='999999';
//        // $results[0]['MD_HVT_F']='999999';
//        // $results[0]['MD_GWM']='999999';
//        // $results[0]['MD_TGW_THRTK']='999999';
//        // $results[0]['IS_ELF']='999999';
//        // $results[0]['ECR']='999999';
//        // $results[0]['IS_LPD']='999999';
//        // $results[0]['IS_WLOB']='999999';
//        // $results[0]['IS_PREOB']='999999';
//        // $results[0]['IS_TEMOB']='999999';
//        // $results[0]['IS_ESC_HDPD']='999999';
//        // $results[0]['IS_FP_CD']='999999';
//        // $ss[0]=$results;
//        // $ss[1]=$count_grade1S;
//        // $ss[2]=$count_grade12;
//        // $ss[3]=$count_grade13;
//        // $ss[4]=$count_grade21;
//        // $ss[5]=$count_grade22;
//        // $ss[6]=$count_grade31;
//        // $ss[7]=$count_grade32;
//        // $ss[8]=$count_grade41;
//        // $ss[9]=$count_grade42;
//        // $ss[10]=$count_grade51;
//        // $ss[11]=$count_grade52;
//        // $ss[12]=$count_grade61;
//        // $ss[13]=$count_grade62;
//        // $ss[14]=$count_grade63;
//        // $ss[15]=$count_grade64;
//        // $ss[16]=$count_grade65;
//        // $ss[17]=$count_grade66;
//        // $ss[18]=$count_grade67;
//        // $ss[19]=$count_grade7;
//        // $ss[20]=$count_grade8;
//        // $ss[21]=$count_grade9;
//        // $ss[22]=$count_grade101;
//        // $ss[23]=$count_grade102;
//        // $ss[24]=$count_grade103;
//        // $ss[25]=$count_grade111;
//        // $ss[26]=$count_grade112;
//        // $ss[27]=$count_grade1_1;
//        // $ss[28]=$count_grade2_1;
//        // $ss[29]=$count_grade1_1+$count_grade2_1;
//        // }
//        // else{
//        $ss[0] = $results;
//        $ss[1] = $count_grade1s;
//        $ss[2] = $count_grade12;
//        $ss[3] = $count_grade13;
//        $ss[4] = $count_grade21;
//        $ss[5] = $count_grade22;
//        $ss[6] = $count_grade31;
//        $ss[7] = $count_grade32;
//        $ss[8] = $count_grade41;
//        $ss[9] = $count_grade42;
//        $ss[10] = $count_grade51;
//        $ss[11] = $count_grade52;
//        $ss[12] = $count_grade61;
//        $ss[13] = $count_grade62;
//        $ss[14] = $count_grade63;
//        $ss[15] = $count_grade64;
//        $ss[16] = $count_grade65;
//        $ss[17] = $count_grade66;
//        $ss[18] = $count_grade67;
//        $ss[19] = $count_grade7;
//        $ss[20] = $count_grade8;
//        $ss[21] = $count_grade9;
//        $ss[22] = $count_grade101;
//        $ss[23] = $count_grade102;
//        $ss[24] = $count_grade103;
//        $ss[25] = $count_grade111;
//        $ss[26] = $count_grade112;
//        $ss[27] = $count_grade1_1;
//        $ss[28] = $count_grade2_1;
//        $ss[29] = $count_grade1_1 + $count_grade2_1;
//        // }
//        // var_dump($ss);
//        return $ss;
//    }
}
