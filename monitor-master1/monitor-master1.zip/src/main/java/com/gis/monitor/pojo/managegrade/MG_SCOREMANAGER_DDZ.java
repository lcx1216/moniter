package com.gis.monitor.pojo.managegrade;




public class MG_SCOREMANAGER_DDZ {
    private String SUBJECT;
    private String EVALUTIONPRO1;
    private String EVALUTIONPRO2;
    private String EVALUTIONPRO3;
    private double MIN;
    private double MAX;
    private double SCORE;
    private int TYPE;
    private String QUANTITY;
    private String EVALUTIONPRO4;
    private String EVALUTIONPRO5;
    private int ID;


    public MG_SCOREMANAGER_DDZ(String SUBJECT, String EVALUTIONPRO1, String EVALUTIONPRO2, String EVALUTIONPRO3, double MIN, double MAX, double SCORE, int TYPE, String QUANTITY, String EVALUTIONPRO4, String EVALUTIONPRO5, int ID) {
        this.SUBJECT = SUBJECT;
        this.EVALUTIONPRO1 = EVALUTIONPRO1;
        this.EVALUTIONPRO2 = EVALUTIONPRO2;
        this.EVALUTIONPRO3 = EVALUTIONPRO3;
        this.MIN = MIN;
        this.MAX = MAX;
        this.SCORE = SCORE;
        this.TYPE = TYPE;
        this.QUANTITY = QUANTITY;
        this.EVALUTIONPRO4 = EVALUTIONPRO4;
        this.EVALUTIONPRO5 = EVALUTIONPRO5;
        this.ID = ID;
    }

    public String getSUBJECT() {
        return SUBJECT;
    }

    public void setSUBJECT(String SUBJECT) {
        this.SUBJECT = SUBJECT;
    }

    public String getEVALUTIONPRO1() {
        return EVALUTIONPRO1;
    }

    public void setEVALUTIONPRO1(String EVALUTIONPRO1) {
        this.EVALUTIONPRO1 = EVALUTIONPRO1;
    }

    public String getEVALUTIONPRO2() {
        return EVALUTIONPRO2;
    }

    public void setEVALUTIONPRO2(String EVALUTIONPRO2) {
        this.EVALUTIONPRO2 = EVALUTIONPRO2;
    }

    public String getEVALUTIONPRO3() {
        return EVALUTIONPRO3;
    }

    public void setEVALUTIONPRO3(String EVALUTIONPRO3) {
        this.EVALUTIONPRO3 = EVALUTIONPRO3;
    }

    public double getMIN() {
        return MIN;
    }

    public void setMIN(double MIN) {
        this.MIN = MIN;
    }

    public double getMAX() {
        return MAX;
    }

    public void setMAX(double MAX) {
        this.MAX = MAX;
    }

    public double getSCORE() {
        return SCORE;
    }

    public void setSCORE(double SCORE) {
        this.SCORE = SCORE;
    }

    public int getTYPE() {
        return TYPE;
    }

    public void setTYPE(int TYPE) {
        this.TYPE = TYPE;
    }

    public String getQUANTITY() {
        return QUANTITY;
    }

    public void setQUANTITY(String QUANTITY) {
        this.QUANTITY = QUANTITY;
    }

    public String getEVALUTIONPRO4() {
        return EVALUTIONPRO4;
    }

    public void setEVALUTIONPRO4(String EVALUTIONPRO4) {
        this.EVALUTIONPRO4 = EVALUTIONPRO4;
    }

    public String getEVALUTIONPRO5() {
        return EVALUTIONPRO5;
    }

    public void setEVALUTIONPRO5(String EVALUTIONPRO5) {
        this.EVALUTIONPRO5 = EVALUTIONPRO5;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }


    @Override
    public String toString() {
        return "MG_SCOREMANAGER_DDZ{" +
                "SUBJECT='" + SUBJECT + '\'' +
                ", EVALUTIONPRO1='" + EVALUTIONPRO1 + '\'' +
                ", EVALUTIONPRO2='" + EVALUTIONPRO2 + '\'' +
                ", EVALUTIONPRO3='" + EVALUTIONPRO3 + '\'' +
                ", MIN='" + MIN + '\'' +
                ", MAX='" + MAX + '\'' +
                ", SCORE='" + SCORE + '\'' +
                ", TYPE='" + TYPE + '\'' +
                ", QUANTITY='" + QUANTITY + '\'' +
                ", EVALUTIONPRO4='" + EVALUTIONPRO4 + '\'' +
                ", EVALUTIONPRO5='" + EVALUTIONPRO5 + '\'' +
                ", ID='" + ID + '\'' +
                //   ", ISLASTEST='" + ISLASTEST + '\'' +
                '}';
    }
}
