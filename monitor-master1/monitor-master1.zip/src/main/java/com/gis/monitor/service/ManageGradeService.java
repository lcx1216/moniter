package com.gis.monitor.service;

import com.gis.monitor.mapper.managegrade.MG_CP_DC_EQ_MAPPER;
import com.gis.monitor.pojo.managegrade.MG_CP_DC_EQ;
import com.gis.monitor.mapper.managegrade.MG_SCOREMANAGER_DDZ_MAPPER;
import com.gis.monitor.pojo.managegrade.MG_SCOREMANAGER_DDZ;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service
public class ManageGradeService {

    @Resource
    MG_CP_DC_EQ_MAPPER mg_cp_dc_eq_mapper;
    public List<MG_CP_DC_EQ> selectList(){
        List<MG_CP_DC_EQ> list = new ArrayList<MG_CP_DC_EQ>();
        list = mg_cp_dc_eq_mapper.selectList();
        return list;
    }
    @Resource
    MG_SCOREMANAGER_DDZ_MAPPER mg_scoremanager_ddz_mapper;
    public List<MG_SCOREMANAGER_DDZ> getSubject(){
        List<MG_SCOREMANAGER_DDZ> list1 = new ArrayList<MG_SCOREMANAGER_DDZ>();
        list1 = mg_scoremanager_ddz_mapper.getSubjectList();
        return list1;
    }


}
