package com.gis.monitor.mapper.basicinfo;



import com.gis.monitor.pojo.basicinfo.BI_MONTHLY_REPORT;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface BI_MONTHLY_REPORT_MAPPER {
    List<BI_MONTHLY_REPORT> getRatingTimeList();
}
