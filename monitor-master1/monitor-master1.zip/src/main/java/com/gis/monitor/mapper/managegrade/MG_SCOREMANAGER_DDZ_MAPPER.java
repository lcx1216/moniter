package com.gis.monitor.mapper.managegrade;

import com.gis.monitor.pojo.managegrade.MG_SCOREMANAGER_DDZ;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;


@Mapper
@Repository
public interface MG_SCOREMANAGER_DDZ_MAPPER {
    List<MG_SCOREMANAGER_DDZ> getSubjectList();
}
