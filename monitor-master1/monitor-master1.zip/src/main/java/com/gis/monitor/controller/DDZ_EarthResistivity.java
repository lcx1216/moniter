package com.gis.monitor.controller;

/*
   地电阻查询(改)-跟踪应用评估
 */

import com.gis.monitor.pojo.managegrade.MG_CP_DC_EQ;
import com.gis.monitor.service.ManageGradeService;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

public class DDZ_EarthResistivity {
    @Resource
    ManageGradeService manageGradeService;
    BasicInfoService basicInfoService;
    public List<String> DDZ_EarthResistivity(String station_Name, String station_id, String item_id, String point_id ) {
        //
        List<MG_CP_DC_EQ> MouthGrade = new ArrayList<MG_CP_DC_EQ>();
        MouthGrade = manageGradeService.selectList();
        List<MG_SCOREMANAGER_DDZ> MouthGrade = new ArrayList<MG_SCOREMANAGER_DDZ>();
        MouthGrade = manageGradeService.getSubjectList();
        List<BI_MONTHLY_REPORT> Trace = new ArrayList<BI_MONTHLY_REPORT>();
        Trace = basicInfoService.getRatingTimeList();
        List<BI_SUB_EARTHRESISTIVITY> EarthData = new ArrayList<BI_SUB_EARTHRESISTIVITY>();
        EarthData = basicInfoService.getStationIdList();
        String Ear_iteam_id = item_id.substring(0,3);
        String Ear_point_id = point_id;
        String AllEarthData = select STATIONID as station_id, ITEMID as Ear_item_id, POINTID as Ear_point_id from earthdata;
        String MouthTime =





    }
//    public DDZ_EarthResistivity(String station_Name, String station_id, String item_id, String point_id) {
//        //表准备
//        MouthGrade = M('scoremanager_ddz', 'mg_', 'CONFIG_JC_MANAGEGRADE'); //    评分对比表     // 查询 CONFIG_JC_MANAGEGRADE 数据库，前缀为mg_开头的表， 根据scoremanager_ddz转化成 MouthGrade对象
//        Trace = M('bi_monthly_report', '', 'CONFIG_JC_BASICINFO'); //月表           // 查询 CONFIG_JC_BASICINFO 数据库，按照当前项目配置的前缀， 根据bi_monthly_report模型转化成 Trace对象
//        EarthData = M('sub_earthresistivity', 'bi_', 'CONFIG_JC_BASICINFO'); //地电阻所有基础数据   // 查询 CONFIG_JC_BASICINFO 数据库，前缀为bi_开头的表， 根据sub_earthresistivity模型转化成 Trace对象
//        //数据准备
//        item_id = substr(0,3);
//        String Ear_item_id = item_id;
//        //String Ear_item_id = substr(item_id, 0, 3);
//        String Ear_point_id = point_id;
//        AllEarthData = EarthData->where("STATIONID='%s' and ITEMID = '%s' and POINTID = '%s' ", station_id, Ear_item_id, Ear_point_id)->limit(2)->select(); //评分表里所选台站所有信息    // 根据条件查询出地电阻所有基础数据数据
//        //var_dump($AllEarthData);
//        //所选台站最近的时间
//        MouthTime = Trace->field("MAX(RATINGTIME)")->where("STATIONID='%s' and ITEMID='%s' and POINTID='%s'", station_id, item_id, point_id)->select(); // 根据条件获取Trace中字段RATINGTIME的最大值
//        AllDate = MouthTime[0]['MAX(RATINGTIME)'];
//        //var_dump($AllDate);
//        //一。月报得分计算1.0计算监测运行管理得分(月报)
//        grade = Trace->field('SCORE')->where("STATIONID='%s' and ITEMID='%s' and POINTID='%s' and STATE='%s' and RATINGTIME='%s'", station_id, item_id, point_id, 1, AllDate)->select();
//        //权重提取
//        mouthgrade = MouthGrade->field('SCORE')->where("EVALUATIONPRO3='台站运行管理得分'")->select();
//        mgrade = grade[0]['SCORE'];
//        //var_dump($mgrade);
//        //获取满分（即该学科最高分）
//        DBmonth = M('bi_monthly_report', '', 'CONFIG_JC_BASICINFO');
//        MarkArray = DBmonth->field('SCORE')->where("ITEMID LIKE '32%' and STATE='1' and RATINGTIME='$AllDate'")->select();
//        //var_dump($MarkArray);
//        key = array_search(max(MarkArray), MarkArray); //获取最大值下标
//        //var_dump($key);
//        HighestMark = MarkArray[key]['SCORE'];
//        // var_dump($HighestMark);
//        //$usegrade=intval($mgrade/$mouthgrade[0]['SCORE']);//月报成绩
//        if (mgrade == null || mgrade == 999999) {
//            mgrade = 999999;
//            mouthgrade[0]['SCORE'] = 0;
//            usegrade = 0;
//            //$usegrade = (double) $mouthgrade[0]['SCORE'] * ($mgrade / $HighestMark);
//
//        } else {
//            usegrade = (double)mouthgrade[0]['SCORE'] * (mgrade / HighestMark);
//        }
//        usegrade = round(usegrade, 2);
//        //var_dump($usegrade);
//        //二、系统运行状态2.1.1 供电线漏电电流与供电电流的比值不应大于0.1％，供电线漏电电位差绝对值与人工电位差的比值不应大于0.5％
//        IS_LCPS = AllEarthData[0]['IS_LCPS'];
//        ElectricityRatio = MouthGrade->field('SCORE,TYPE')->where("EVALUATIONPRO4='供电线漏电电流与供电电流的比值不应大于0.1％，供电线漏电电位差绝对值与人工电位差的比值不应大于0.5％'")->select();
//        for (int i = 0;i <= 1;i++) {
//            if (IS_LCPS == 999999) {
//                ElectricityRatioGrade = 0;
//            } else if (IS_LCPS == ElectricityRatio[i]['TYPE']) {
//                ElectricityRatioGrade = (double)$ElectricityRatio[i]['SCORE'];
//            } else if (IS_LCPS == null) {
//                IS_LCPS = 999999;
//                ElectricityRatioGrade = 0;
//            }
//        }
//        //二、系统运行状态2.1.2 测量线对地绝缘电阻不应小于5 MΩ
//        IS_MLGI_SFM = AllEarthData[0]['IS_MLGI_SFM'];
//        ResistanceCotton = MouthGrade->field('SCORE,TYPE')->where("EVALUATIONPRO4='测量线对地绝缘电阻不应小于5 MΩ'")->select();
//        for (int i = 0;i <= 1;i++) {
//            if (IS_MLGI_SFM == 999999) {
//                ResistanceCottonGrade = 0;
//            } else if (IS_MLGI_SFM == ResistanceCotton[i]['TYPE']) {
//                ResistanceCottonGrade = (double)ResistanceCotton[i]['SCORE'];
//            } else if (IS_MLGI_SFM == null) {
//                IS_MLGI_SFM = 999999;
//                ResistanceCottonGrade = 0;
//            }
//        }
//        //二、系统运行状态2.2.1 供电电极单电极接地电阻不应大于30Ω
//        IS_SEGR_THRO = AllEarthData[0]['IS_SEGR_THRO'];
//        TouchResistance = MouthGrade->field('SCORE,TYPE')->where("EVALUATIONPRO4='供电电极单电极接地电阻不应大于30Ω'")->select();
//        for (int i = 0;i <= 1;i++) {
//            if (IS_SEGR_THRO == 999999) {
//                TouchResistanceGrade = 0.5;
//            } else if (IS_SEGR_THRO === TouchResistance[i]['TYPE']) {
//                TouchResistanceGrade = (double)TouchResistance[i]['SCORE'];
//            } else if (IS_SEGR_THRO == null) {
//                IS_SEGR_THRO = 999999;
//                TouchResistanceGrade = 0.5;
//            }
//        }
//        //二、系统运行状态2.2.2 测量电极单电极接地电阻不应大于100Ω
//        IS_MSE_HRUO = AllEarthData[0]['IS_MSE_HRUO'];
//        TouchResistanceOne = MouthGrade->field('SCORE,TYPE')->where("EVALUATIONPRO4='测量电极单电极接地电阻不应大于100Ω'")->select();
//        for (int i = 0;i <= 1;i++) {
//            if (IS_MSE_HRUO === 0 || IS_MSE_HRUO == 999999) {
//                TouchResistanceOneGrade = 0.5;
//            } else if (IS_MSE_HRUO === TouchResistanceOne[i]['TYPE']) {
//                TouchResistanceOneGrade = (double)TouchResistanceOne[i]['SCORE'];
//            } else if (IS_MSE_HRUO == null) {
//                IS_MSE_HRUO = 999999;
//                TouchResistanceOneGrade = 0.5;
//            }
//        }
//        // var_dump($IS_MSE_HRUO);
//        // var_dump($TouchResistanceOne);
//        //二、系统运行状态2.3.1 输出电流：0.5 A～2.5 A
//        IS_OUTCU_BET_A = AllEarthData[0]['IS_OUTCU_BET_A'];
//        OutElectricity = MouthGrade->field('SCORE,TYPE')->where("EVALUATIONPRO4='输出电流：0.5 A～2.5 A'")->select();
//        for (int i = 0;i <= 1;i++) {
//            if (IS_OUTCU_BET_A == 999999) {
//                OutElectricityGrade = 0;
//            } else if (IS_OUTCU_BET_A === OutElectricity[i]['TYPE']) {
//                OutElectricityGrade = (double)OutElectricity[i]['SCORE'];
//            } else if (IS_OUTCU_BET_A == null) {
//                IS_OUTCU_BET_A = 999999;
//                OutElectricityGrade = 0;
//            }
//        }
//        //var_dump($IS_OUTCU_BET_A);
//        //var_dump($OutElectricityGrade);
//        //二、系统运行状态2.3.2 纹波因数：小于0.5％
//        IS_RIFA_S = AllEarthData[0]['IS_RIFA_S'];
//        CurrugateSubmultiple = MouthGrade->field('SCORE,TYPE')->where("EVALUATIONPRO4='纹波因数：小于0.5％'")->select();
//        for (int i = 0;i <= 1;i++) {
//            if (IS_RIFA_S == 999999) {
//                CurrugateSubmultipleGrade = 0.1;
//            } else if (IS_RIFA_S === CurrugateSubmultiple[i]['TYPE']) {
//                CurrugateSubmultipleGrade = (double)CurrugateSubmultiple[i]['SCORE'];
//            } else if (IS_RIFA_S == null) {
//                IS_RIFA_S = 999999;
//                CurrugateSubmultipleGrade = 0.1;
//            }
//        }
//        //var_dump($IS_RIFA_S);
//        //var_dump($CurrugateSubmultipleGrade);
//        //var_dump($IS_RIFA_S);
//        //二、系统运行状态2.3.2 电流稳定度：优于0.5％
//        IS_CSB_ = AllEarthData[0]['IS_CSB_'];
//        ElectricityPrecarious = MouthGrade->field('SCORE,TYPE')->where("EVALUATIONPRO4='电流稳定度：优于0.5％'")->select();
//        for (int i = 0;i <= 1;i++) {
//            if (IS_CSB_ == 999999) {
//                ElectricityPrecariousGrade = 0.1;
//            } else if (IS_CSB_ === ElectricityPrecarious[i]['TYPE']) {
//                ElectricityPrecariousGrade = (double)ElectricityPrecarious[i]['SCORE'];
//            } elseif (IS_CSB_ == null) {
//                IS_CSB_ = 999999;
//                ElectricityPrecariousGrade = 0.1;
//            }
//        }
//        //二、系统运行状态2.4.1-2.4.9 测量自然电位差时分辨率不低于0.01 mV；
//        IS_OBINSRE = AllEarthData[0]['IS_OBINSRE'];
//        NatureElectricity = MouthGrade->field('SCORE,TYPE')->where("EVALUATIONPRO3='观测仪器'")->select();
//        for (int i = 0;i <= 1;i++) {
//            if (IS_OBINSRE == 999999) {
//                NatureElectricityGrade = 0;
//            } else if (IS_OBINSRE === NatureElectricity[i]['TYPE']) {
//                NatureElectricityGrade = (double)NatureElectricity[i]['SCORE'];
//            } else if (IS_OBINSRE == null) {
//                IS_OBINSRE = 999999;
//                NatureElectricityGrade = 0;
//            }
//        }
//        //三、观测干扰情况3.1.1 基建施工、金属管网设施类干扰源
//        BaseScore = MouthGrade->field('SCORE')->where("EVALUATIONPRO3='基建总分'")->select();
//        COIN_INSOU_NUM = AllEarthData[0]['COIN_INSOU_NUM'];
//        BaseSource = $MouthGrade->field('SCORE,TYPE')->where("EVALUATIONPRO4='基建施工、金属管网设施类干扰源'")->select();
//        if (COIN_INSOU_NUM == null || COIN_INSOU_NUM == 999999) {
//            COIN_INSOU_NUM = 999999;
//            BaseSourceGrade = 0;
//        } else if (COIN_INSOU_NUM <= 10 && !is_null(COIN_INSOU_NUM)) {
//            BaseSourceGrade = (double)BaseScore[0]['SCORE'] + (double)COIN_INSOU_NUM * BaseSource[0]['SCORE'];
//        } else if (COIN_INSOU_NUM > 10 && COIN_INSOU_NUM < 999999) {
//            BaseSourceGrade = 0;
//        } else {
//            BaseSourceGrade = 0;
//            COIN_INSOU_NUM = 999999;
//        }
//        //var_dump($COIN_INSOU_NUM);
//        //var_dump($BaseSourceGrade);
//        //三、观测干扰情况3.2.1 自然环境类干扰源
//        NatureScore = $MouthGrade->field('SCORE')->where("EVALUATIONPRO3='自然总分'")->select();
//        INSOEN_NUM = AllEarthData[0]['INSOEN_NUM']; //多少个
//        //var_dump($INSOEN_NUM);
//        NatureDisturb = MouthGrade->field('SCORE,TYPE')->where("EVALUATIONPRO3='自然环境类干扰源'")->select();
//        if (INSOEN_NUM == 999999) {
//            NatureDisturbGrade = 0;
//        } else if (INSOEN_NUM <= 5 && !is_null(INSOEN_NUM)) {
//            NatureDisturbGrade = (double)NatureScore[0]['SCORE'] + (double)INSOEN_NUM * NatureDisturb[0]['SCORE'];
//        } else if (INSOEN_NUM > 5) {
//            NatureDisturbGrade = 0;
//        } else {
//            INSOEN_NUM = 999999;
//            NatureDisturbGrade = 0;
//        }
//        //var_dump($NatureDisturbGrade);
//        //四、震例情况
//        ExempleEarthQuake = JC_EQ_situation(station_Name, station_id, item_id); //引用翔哥函数进行读数据
//        separate = explode('||', ExempleEarthQuake);
//        EarthQuakeConnect = separate[0]; //内容
//        EarthQuakevalue = separate[1]; //值
//        //var_dump("111".$EarthQuakevalue);
//        //var_dump($ElectricityRatioGrade,$usegrade,$ResistanceCottonGrade,$TouchResistanceGrade,$TouchResistanceOneGrade,$OutElectricityGrade,$CurrugateSubmultipleGrade,$ElectricityPrecariousGrade,$NatureElectricityGrade,$BaseSourceGrade,$NatureDisturbGrade,$EarthQuakevalue);
//        //$EleGrade=$MouthGrade->field('SCORE')->where("EVALUATIONPRO3='台项周围200km内无5级以上地震'")->select();
//        // if($EarthQuakeConnect=='不符合前述条件的其他情况'){
//        //     $EleGrade=$MouthGrade->field('SCORE')->where("EVALUATIONPRO3='不符合前述条件的其他情况'")->select();
//        //     $EleQuaGrade=$EleGrade[0]['SCORE'];
//        // }else if ($EarthQuakeConnect=='近5年内震例预报效能') {
//        //     $EleGrade=$MouthGrade->field('MIN ,MAX ,SCORE')->where("EVALUATIONPRO3='近5年内震例预报效能'")->select();
//        //     for($i=0;$i<=2;$i++){
//        //         if($EleGrade[i]['MIN']==3&&$EleGrade[i]['MIN']==999999){
//        //             $EleQuaGrade = $EleGrade[i]['SCORE'];
//        //         }else if ($EleGrade[i]['MIN']==2&&$EleGrade[i]['MIN']==3) {
//        //             $EleQuaGrade = $EleGrade[i]['SCORE'];
//        //         }else if ($EleGrade[i]['MIN']==1&&$EleGrade[i]['MIN']==2) {
//        //             $EleQuaGrade = $EleGrade[i]['SCORE'];
//        //         }
//        //     }
//        // }elseif($EarthQuakeConnect=='近5年内无震例,但观测以来存在震例'){
//        //     $EleGrade=$MouthGrade->field('MIN ,MAX ,SCORE')->where("EVALUATIONPRO3='近5年内无震例,但观测以来存在震例'")->select();
//        //     for($i=0;$i<=2;$i++){
//        //         if($EleGrade[i]['MIN']==3&&$EleGrade[i]['MIN']==999999){
//        //             $EleQuaGrade = $EleGrade[i]['SCORE'];
//        //         }elseif ($EleGrade[i]['MIN']==2&&$EleGrade[i]['MIN']==3) {
//        //             $EleQuaGrade = $EleGrade[i]['SCORE'];
//        //         }elseif ($EleGrade[i]['MIN']==1&&$EleGrade[i]['MIN']==2) {
//        //             $EleQuaGrade = $EleGrade[i]['SCORE'];
//        //         }
//        //     }
//        // }elseif ($EarthQuakeConnect=='台项周围200km内有5级以上地震') {
//        //     $EleGrade=$MouthGrade->field('SCORE')->where("EVALUATIONPRO3='台项周围200km内有5级以上地震'")->select();
//        //     $EleQuaGrade=$EleGrade[0]['SCORE'];
//        // }
//        //苏苏改动
//        //我觉得应该是数据跟评分规则相比较而不是对评分规则做判断
//        if (EarthQuakeConnect == '不符合前述条件的其他情况') {
//            EleQuaGrade = 0;
//        } else if (EarthQuakeConnect == '近5年内震例预报效能') {
//            if (EarthQuakevalue >= 3) {
//                EleQuaGrade = 25;
//            } elseif (EarthQuakevalue == 2) {
//                EleQuaGrade = 20;
//            } elseif (EarthQuakevalue == 1) {
//                EleQuaGrade = 15;
//            # code...
//
//            } else {
//                EleQuaGrade = 999999;
//            }
//        } else if (EarthQuakeConnect == '近5年内无震例,但观测以来存在震例') {
//            if (EarthQuakevalue >= 3) {
//                EleQuaGrade = 15;
//            } elseif (EarthQuakevalue == 2) {
//                EleQuaGrade = 12;
//            } elseif (EarthQuakevalue == 1) {
//                EleQuaGrade = 10;
//            # code...
//
//            } else {
//                EleQuaGrade = 999999;
//            }
//        } else if (EarthQuakeConnect == '台项周围200km内有5级以上地震') {
//            EleQuaGrade = 5;
//        }
//        sum = ElectricityRatioGrade + usegrade + ResistanceCottonGrade + TouchResistanceGrade + TouchResistanceOneGrade + OutElectricityGrade + CurrugateSubmultipleGrade + ElectricityPrecariousGrade + NatureElectricityGrade + BaseSourceGrade + NatureDisturbGrade + EleQuaGrade;
//        //返回数组
//        arr = array();
//        if (mgrade == '') {
//            arr[0] = 0; //月报成绩
//
//        } else {
//            arr[0] = mgrade; //月报成绩
//
//        }
//        arr[1] = usegrade; //比重月报成绩
//        //  var_dump($arr[0]);
//        arr[16] = IS_LCPS;
//        arr[17] = IS_MLGI_SFM;
//        arr[18] = IS_SEGR_THRO;
//        arr[19] = IS_MSE_HRUO;
//        arr[20] = IS_OUTCU_BET_A;
//        arr[21] = IS_RIFA_S;
//        arr[22] = IS_CSB_;
//        arr[23] = IS_OBINSRE;
//        arr[2] = ElectricityRatioGrade; //二、系统运行状态2.1.1 供电线漏电电流与供电电流的比值不应大于0.1％，供电线漏电电位差绝对值与人工电位差的比值不应大于0.5％
//        arr[3] = ResistanceCottonGrade; //二、系统运行状态2.1.2 测量线对地绝缘电阻不应小于5 MΩ
//        arr[4] = TouchResistanceGrade; //二、系统运行状态2.2.1 供电电极单电极接地电阻不应大于30Ω
//        arr[5] = TouchResistanceOneGrade; //二、系统运行状态2.2.2 测量电极单电极接地电阻不应大于100Ω
//        arr[6] = OutElectricityGrade; //二、系统运行状态2.3.1 输出电流：0.5 A～2.5 A
//        arr[7] = CurrugateSubmultipleGrade; //二、系统运行状态2.3.2 纹波因数：小于0.5％
//        arr[8] = ElectricityPrecariousGrade; //二、系统运行状态2.3.2 电流稳定度：优于0.5％
//        arr[9] = NatureElectricityGrade; //二、系统运行状态2.4.1-2.4.9 测量自然电位差时分辨率不低于0.01 mV；
//        arr[10] = BaseSourceGrade; //三、观测干扰情况3.1.1 基建施工、金属管网设施类干扰源
//        ///  var_dump('观测干扰情况3.1.1 基建施工、金属管网设施类干扰源 $arr[10]'.$arr[10]);
//        arr[14] = COIN_INSOU_NUM;
//        arr[11] = NatureDisturbGrade; //三、观测干扰情况3.2.1 自然环境类干扰源
//        arr[15] = INSOEN_NUM;
//        //var_dump('$arr[11]观测干扰情况3.2.1 自然环境类干扰源'.$arr[11]);
//        arr[12] = EarthQuakeConnect; //四、震例情况内容
//        arr[13] = EarthQuakevalue; //四、震例情况值
//        arr[25] = EleQuaGrade;
//        //var_dump("zhenglei".$EleQuaGrade);
//        arr[24] = sum;
//        // var_dump("ssss".$arr[24]);
//        return arr;
//    }
}
