package com.gis.monitor.controller;


/*
    地电阻质量评价
 */


public class MG_PF_DDZ {
    private String obj;

//    public MG_PF_DDZ(String obj) {
//        mode = M('mg_scoremanager_ddz', '', 'CONFIG_JC_MANAGEGRADE');
//        /*$rs1=($obj->{'可靠性'} == null ? 0 : $obj->{'可靠性'});*/
//        //1.1.1 可靠性：依据电测深曲线计算台站观测理论值范围
//        rs1 = rand(-2, 2) / 10; //按要求生成随机的-0.2~0.2的数字，结果直接给4分
//        rs11 = 4;
//    /*$result1= $mode ->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO3 like '可靠性%'")->order ('id')->select();
//    // var_dump($result1);
//      if ($rs1*100 >= $result1[0][MIN] && $rs1 <999999) { $rs11 = $result1[0][SCORE]; }
//      else if ($rs1*100 >= $result1[1][MIN] && $rs1*100 < $result1[1][MAX]) { $rs11 = $result1[1][SCORE]; }
//      else if ($rs1*100 < $result1[2][MAX]) { $rs11 = $result1[2][SCORE]; }
//    */
//        //1.1.2 稳定性：日均值资料连续变化规律（阶跃性变化），目前回溯3年；
//        rs2 = (obj->{'稳定性'} === null ? 999999 : obj->{'稳定性'});
//        //$rs2=$rs2*(-1);
//        result2 = mode->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO3 like '稳定性%'")->order('id')->select();
//        //var_dump($result2);
//        //exit;
//        if (rs2 == result2[0][MIN]) {
//            rs21 = result2[0][SCORE];
//        } else if (rs2 == result2[1][MIN]) {
//            rs21 = result2[1][SCORE];
//        } else if (rs2 <= result2[2][MAX] && rs2 >= result2[2][MIN]) {
//            rs21 = result2[2][SCORE];
//        } else if (rs2 > result2[3][MIN] && rs2 < 999999) {
//            rs21 = result2[3][SCORE];
//        } else {
//            rs2 = 999999;
//            rs21 = result2[3][SCORE];
//        }
//        //1.1.3 连续性：连续缺数1个月以上计为缺数，目前回溯3年（4分）；
//        rs3 = (obj->{'连续性'} == null ? 999999 : obj->{'连续性'});
//        result3 = mode->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO3 like '连续性%'")->order('id')->select();
//        //var_dump($result3);
//        // exit;
//        if (rs3 == result3[0][MIN]) {
//            rs31 = result3[0][SCORE];
//        } else if (rs3 <= result3[3][MAX] && !is_null(rs3)) {
//            rs31 = result3[3][SCORE];
//        } else if (rs3 <= result3[1][MAX] && rs3 > result3[1][MIN]) {
//            rs31 = result3[1][SCORE];
//        } else if (rs3 <= result3[2][MAX] && rs3 > result3[2][MIN]) {
//            rs31 = result3[2][SCORE];
//        } else {
//            rs3 = 999999;
//            rs31 = result3[3][SCORE];
//        }
//        //1.1.4 观测精度：日均值资料与半年变周期以上成分均方差，目前回溯3年；
//        rs4 = (obj->{'观测精度'} === null ? 999999 : obj->{'观测精度'});
//        if (rs4 == "非数字") {
//            rs4 = 999999;
//        }
//        result4 = mode->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO3 like '观测精度%'")->order('id')->select();
//        // var_dump($result4);
//        // exit;
//        if (rs4 < result4[3][MAX] && !is_null(rs4)) {
//            rs41 = result4[3][SCORE];
//        } else if (rs4 >= result4[0][MIN] && rs4 < result4[0][MAX]) {
//            rs41 = result4[0][SCORE];
//        } else if (rs4 >= result4[1][MIN] && rs4 <= result4[1][MAX]) {
//            rs41 = result4[1][SCORE];
//        } else if (rs4 > result4[2][MIN]) {
//            rs41 = result4[2][SCORE];
//        } else {
//            rs4 = 999999;
//            rs41 = result4[2][SCORE];
//        }
//        //1.1.5 年变特征，目前回溯5年（3分）；
//        rs5 = (obj->{'年变特征'} == null ? 999999 : obj->{'年变特征'});
//        if (rs5 == "非数字") {
//            rs5 = 999999;
//        }
//        result5 = mode->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO3 like '年变特征%'")->order('id')->select();
//        // var_dump($result5); //binbug
//        // exit;
//        if (rs5 > result5[0][MIN] && rs5 < 999999) {
//            rs51 = result5[0][SCORE];
//        } else if (rs5 >= result5[1][MIN] && rs5 <= result5[1][MAX]) {
//            rs51 = result5[1][SCORE];
//        } else if (rs5 < result5[2][MAX] && !is_null(rs5)) {
//            rs51 = result5[2][SCORE];
//        }
//        // else if ($rs5 < $result5[3][MAX]) { $rs51 = $result5[3][SCORE]; }
//        else {
//            rs5 = 999999;
//            rs51 = result5[2][SCORE];
//        }
//        //1.1.6 观测长度（2分）；
//        rs6 = (obj->{'观测长度'} == null ? 999999 : obj->{'观测长度'});
//        result6 = mode->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO3 like '观测长度%'")->order('id')->select();
//        // var_dump($result6);
//        // exit;
//        /* 返回的数据类型为0.75 乘以10，有误则不乘*/
//        if (rs6 > result6[0][MIN] && rs6 < 999999) {
//            rs61 = result6[0][SCORE];
//        } else if (rs6 >= result6[1][MIN] && rs6 < result6[1][MAX]) {
//            rs61 = result6[1][SCORE];
//        } else if (rs6 < result6[2][MAX] && !is_null(rs6)) {
//            rs61 = result6[2][SCORE];
//        } else {
//            rs6 = 999999;
//            rs61 = result6[2][SCORE];
//        }
//        //2 辅助观测资料（8分）
//        //zrf添加辅助测项完整率
//        //2.1.1 潜水位观测连续性：连续缺数1个月以上计为缺数，目前回溯3年
//        rs7 = (obj->{'潜水位观测连续性'} == null ? 999999 : obj->{'潜水位观测连续性'});
//        if (rs7 == '999,999.00') {
//            rs7 = 999999;
//        }
//        //$rs7=$rs7*(-1);
//        result7 = mode->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO4 like '潜水位观测连续性%' ")->order('id')->select();
//        // var_dump($result7);
//        // exit;
//        if (rs7 == 0) {
//            rs71 = result7[0][SCORE];
//        } else if (rs7 == 999999) {
//            rs71 = result7[3][SCORE];
//        } else if (rs7 * (-1) <= result7[3][MAX] && rs7 > 0) {
//            rs71 = result7[3][SCORE];
//        } else if (rs7 * (-1) > result7[1][MIN] && rs7 * (-1) <= result7[1][MAX]) {
//            rs71 = result7[1][SCORE];
//        } else if (rs7 * (-1) > result7[2][MIN] && rs7 * (-1) <= result7[2][MAX]) {
//            rs71 = result7[2][SCORE];
//        } else {
//            rs7 = 999999;
//            rs71 = result7[3][SCORE];
//        }
//        //2.1.2 潜水位观测长度（1分）；
//        rs8 = (obj->{'潜水位观测长度'} == null ? 999999 : obj->{'潜水位观测长度'});
//        result8 = mode->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO4 = '潜水位观测长度' ")->order('id')->select();
//        //  var_dump($result8);
//        // exit;
//        if (rs8 > result8[0][MIN] && rs8 <= 999999) {
//            rs81 = result8[0][SCORE];
//        } else if (rs8 >= result8[1][MIN] && rs8 <= result8[1][MAX]) {
//            rs81 = result8[1][SCORE];
//        } else if (rs8 < result8[2][MAX] && !is_null(rs8)) {
//            rs81 = result8[2][SCORE];
//        } else {
//            rs8 = 999999;
//            rs81 = result8[2][SCORE];
//        }
//        //2.2.1 降雨量观测连续性：连续缺数1个月以上计为缺数，目前回溯3年
//        rs9 = (obj->{'降雨量观测连续性'} == null ? 999999 : obj->{'降雨量观测连续性'});
//        //rs9=rs9*(-1);
//        result9 = mode->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO4 like '降雨量观测连续性%' ")->order('id')->select();
//        // var_dump($result9);
//        // exit;
//        if (rs9 === 0) {
//            rs91 = result9[0][SCORE];
//        } else if (rs9 * (-1) > result9[1][MIN] && rs9 * (-1) <= result9[1][MAX]) {
//            rs91 = result9[1][SCORE];
//        } else if (rs9 * (-1) > result9[2][MIN] && rs9 * (-1) <= result9[2][MAX]) {
//            rs91 = result9[2][SCORE];
//        } else if (rs9 * (-1) > 0 && rs9 * (-1) <= result9[2][MAX]) {
//            rs91 = result9[3][SCORE];
//        } else {
//            rs9 = 999999;
//            rs91 = result9[3][SCORE];
//        }
//        //2.2.2 降雨量观测长度（1分）；
//        rs10 = (obj->{'降雨量观测长度'} == null ? 999999 : obj->{'降雨量观测长度'});
//        result10 = mode->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO4 = '降雨量观测长度' ")->order('id')->select();
//        // var_dump($result10);
//        // exit;
//        if (rs10 > result10[0][MIN] && rs10 < 999999) {
//            rs101 = result10[0][SCORE];
//        } else if (rs10 >= result10[1][MIN] && rs10 <= result10[1][MAX]) {
//            rs101 = result10[1][SCORE];
//        } else if (rs10 < result10[2][MAX] && !is_null(rs10)) {
//            rs101 = result10[2][SCORE];
//        } else {
//            rs10 = 999999;
//            rs101 = result10[2][SCORE];
//        }
//        rs1s = (obj->{'温度观测连续性'} == null ? 999999 : obj->{'温度观测连续性'});
//        // $rs1s=$rs1s*(-1);
//        result11 = mode->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO4 like '温度观测连续性%' ")->order('id')->select();
//        //var_dump($result11);
//        // exit;
//        if (rs1s == 0) {
//            rs111 = result11[0][SCORE];
//        } else if (rs1s * (-1) / 12 >= result11[1][MIN] && rs1s * (-1) / 12 < result11[1][MAX]) {
//            rs111 = result11[1][SCORE];
//        } else if (rs1s * (-1) / 12 >= result11[2][MIN] && rs1s * (-1) / 12 <= result11[2][MAX]) {
//            rs111 = result11[2][SCORE];
//        } else if (rs1s * (-1) / 12 > 0 && rs1s * (-1) / 12 < result11[3][MAX]) {
//            rs111 = result11[3][SCORE];
//        } else {
//            rs1s = 999999;
//            rs111 = result11[3][SCORE];
//        }
//        rs12 = (obj->{'温度观测长度'} == null ? 999999 : obj->{'温度观测长度'});
//        result12 = mode->field("EVALUATIONPRO3,to_char(MIN,'000000.00') as MIN,to_char(MAX,'000000.00') as MAX,SCORE,TYPE")->where("EVALUATIONPRO1='数据质量评价' AND EVALUATIONPRO4 = '温度观测长度' ")->order('id')->select();
//        // var_dump($result12);
//        // exit;
//        if (rs12 > result12[0][MIN] && rs12 < 999999) {
//            rs121 = result12[0][SCORE];
//        } else if (rs12 >= result12[1][MIN] && rs12 <= result12[1][MAX]) {
//            rs121 = result12[1][SCORE];
//        } else if (rs12 > 0 && rs12 < result12[2][MAX]) {
//            rs121 = result12[2][SCORE];
//        } else {
//            rs12 = 999999;
//            rs121 = result12[2][SCORE];
//        }
//        totalgrade = intval(rs11 + rs21 + rs31 + rs41 + rs51 + rs61 + rs71 + rs81 + rs91 + rs101 + rs111 + rs121);
//        obj->{'可靠性'} = rs1;
//        obj->{'稳定性'} = rs2;
//        obj->{'连续性'} = rs3;
//        obj->{'观测精度'} = rs4;
//        obj->{'年变特征'} = rs5;
//        obj->{'观测长度'} = rs6;
//        obj->{'潜水位观测连续性'} = rs7;
//        obj->{'潜水位观测长度'} = rs8;
//        obj->{'降雨量观测连续性'} = rs9;
//        obj->{'降雨量观测长度'} = rs10;
//        obj->{'温度观测连续性'} = rs1s;
//        obj->{'温度观测长度'} = rs12;
//        obj->{'可靠性_grade'} = rs11;
//        obj->{'稳定性_grade'} = rs21;
//        obj->{'连续性_grade'} = rs31;
//        obj->{'观测精度_grade'} = rs41;
//        obj->{'年变特征_grade'} = rs51;
//        obj->{'观测长度_grade'} = rs61;
//        obj->{'潜水位观测连续性_grade'} = rs71;
//        obj->{'潜水位观测长度_grade'} = rs81;
//        obj->{'降雨量观测连续性_grade'} = rs91;
//        obj->{'降雨量观测长度_grade'} = rs101;
//        obj->{'温度观测连续性_grade'} = (double)rs111;
//        obj->{'温度观测长度_grade'} = rs121;
//        obj->{'totalgrade'} = totalgrade;
//        return obj;
//
//    }
}
