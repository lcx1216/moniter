package com.gis.monitor;

import com.gis.monitor.mapper.basicinfo.BI_USERS_MAPPER;
import com.gis.monitor.pojo.basicinfo.BI_USERS;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.SQLException;

@SpringBootTest
class MonitorApplicationTests {
    @Autowired
    private BI_USERS_MAPPER bi_users_mapper;
    @Test
    void contextLoads() throws SQLException {
        BI_USERS bi_users = bi_users_mapper.login("DIDIANZU", "didianzu");
        System.out.println(bi_users);
    }

}
